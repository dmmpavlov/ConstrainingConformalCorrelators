[b1, b2, b3] -> { [] -> 1 : (b1 + b2 + b3) mod 2 = 0 and b2 >= b1 and b2 <= b3 <= b1 + b2 }
