# =============================================================================
# Generates barvinok input files (".barv" format)
# for every polytope appearing in "Constraining Conformal Correlators":
#
#    1. P(K_n, b)   fractional PERFECT b-matching polytope        (eq. 23)
#    2. FM_b(K_n)   fractional (non-perfect) b-matching polytope  (eq. 22)
#    3. C_n(s)      conformal n-point polytope                    (Def. 3.6)
#    4. T(r,c)      transportation polytope                       (App. A)
#
#  Each family is produced in two modes:
#       :ordered   -> distinct parameters in increasing ordering b_1 <= ... <= b_n
#       :equal     -> a single parameter; uniform case, all spins equal 
#
#  -------------------------------------------------------------------------
#  FILE FORMAT 
#
#     <m>  <ncols>                              # POLYTOPE matrix, ncols = 2 + nvars + nparams
#     <m rows: flag | vars | params | const>
#     <m'> <nparams+2>                          # constraints on parameters
#     <m' rows: flag | params | const>
#     <param_1> <param_2> ... <param_p>         # parameter names
#
#     flag = 0  ->  ( ... ) = 0      (equality)
#     flag = 1  ->  ( ... ) >= 0     (inequality)
#
#  -------------------------------------------------------------------------
#
#  Usage:
#     include("conformal_polytopes.jl"); using .ConformalPolytopes
#     generate_all(ns = 3:6, dir = "barv")          # write every .barv file
#     run_all("barv", "isl")                        # run barvinok on each
# =============================================================================

module ConformalPolytopes

export write_pmatching, write_fmatching, write_conformal, write_transportation,
       generate_all, run_barvinok, run_all, demo

# ---------------------------------------------------------------------------
#  Build files
# ---------------------------------------------------------------------------

"""Build one polytope row `[flag | vars(nvars) | params(nparams) | const]`."""
function polyrow(flag::Int, nvars::Int, nparams::Int;
                 vcoef = Dict{Int,Int}(), pcoef = Dict{Int,Int}(), c::Int = 0)
    row = zeros(Int, 2 + nvars + nparams)
    row[1] = flag
    for (k, v) in vcoef;  row[1 + k] = v;          end
    for (k, v) in pcoef;  row[1 + nvars + k] = v;  end
    row[end] = c
    return row
end

"""Build one context row `[flag | params(nparams) | const]`."""
function ctxrow(flag::Int, nparams::Int; pcoef = Dict{Int,Int}(), c::Int = 0)
    row = zeros(Int, 2 + nparams)
    row[1] = flag
    for (k, v) in pcoef;  row[1 + k] = v;  end
    row[end] = c
    return row
end

"""Write the polytope block, the context block and the parameter-name line."""
function write_barv(path::AbstractString,
                    P::Vector{Vector{Int}},
                    C::Vector{Vector{Int}},
                    param_names::Vector{String})
    open(path, "w") do io
        println(io, "$(length(P)) $(length(first(P)))")
        for r in P;  println(io, join(r, " "));  end
        println(io, "$(length(C)) $(length(first(C)))")
        for r in C;  println(io, join(r, " "));  end
        println(io, join(param_names, " "))
    end
    return path
end

# edges (i<j) of the complete graph K_n
edges(n::Int) = [(i, j) for i in 1:n for j in i+1:n]

# ---------------------------------------------------------------------------
#  Constraints on parameters
# ---------------------------------------------------------------------------

"""nonneg + chain ordering p_1 <= p_2 <= ... <= p_nparams (for :ordered modes)."""
function ordered_context(nparams::Int)
    rows = Vector{Vector{Int}}()
    for k in 1:nparams                                   # p_k >= 0
        push!(rows, ctxrow(1, nparams; pcoef = Dict(k => 1)))
    end
    for k in 1:nparams-1                                 # p_{k+1} - p_k >= 0
        push!(rows, ctxrow(1, nparams; pcoef = Dict(k => -1, k + 1 => 1)))
    end
    return rows
end

"""single parameter b >= 0 (for :equal modes)."""
equal_context() = [ctxrow(1, 1; pcoef = Dict(1 => 1))]

# ---------------------------------------------------------------------------
#  fractional b-matching polytopes for K_n
#
#  Variables : x_e, one per edge e of K_n           (nvars = C(n,2))
#  Parameters: b_1..b_n  (:ordered)  or  single b   (:equal)
#  Vertex constraint at v:  sum_{e} x_e    (= b_v)  [perfect]
#                                          (<= b_v) [non-perfect]
# ---------------------------------------------------------------------------

function _matching_polytope(n::Int; perfect::Bool, equal::Bool)
    es      = edges(n)
    nvars   = length(es)
    nparams = equal ? 1 : n
    P = Vector{Vector{Int}}()

    for v in 1:n
        inc = Dict{Int,Int}()                            # edges incident to v
        for (idx, (i, j)) in enumerate(es)
            (i == v || j == v) && (inc[idx] = 1)
        end
        pcol = equal ? 1 : v
        if perfect
            # sum x_e - b_v = 0
            push!(P, polyrow(0, nvars, nparams; vcoef = inc, pcoef = Dict(pcol => -1)))
        else
            # b_v - sum x_e >= 0
            neg = Dict(k => -1 for k in keys(inc))
            push!(P, polyrow(1, nvars, nparams; vcoef = neg, pcoef = Dict(pcol => 1)))
        end
    end
    for idx in 1:nvars                                   # x_e >= 0
        push!(P, polyrow(1, nvars, nparams; vcoef = Dict(idx => 1)))
    end

    names = equal ? ["b"] : ["b$i" for i in 1:n]
    ctx   = equal ? equal_context() : ordered_context(nparams)
    return P, ctx, names
end

"""Perfect b-matching polytope P(K_n, b). `mode` ∈ (:ordered, :equal)."""
function write_pmatching(n::Int; mode::Symbol = :ordered, dir::AbstractString = ".")
    P, C, names = _matching_polytope(n; perfect = true,  equal = (mode == :equal))
    write_barv(joinpath(dir, "pmatch_$(mode)_n$(n).barv"), P, C, names)
end

"""Non-perfect b-matching polytope FM_b(K_n). `mode` ∈ (:ordered, :equal)."""
function write_fmatching(n::Int; mode::Symbol = :ordered, dir::AbstractString = ".")
    P, C, names = _matching_polytope(n; perfect = false, equal = (mode == :equal))
    write_barv(joinpath(dir, "fmatch_$(mode)_n$(n).barv"), P, C, names)
end

# ---------------------------------------------------------------------------
#  Conformal n-point polytope C_n(s)                              (Def. 3.6 )
#
#  n(n-3) V coordinates  +  C(n,2) H coordinates
# ---------------------------------------------------------------------------

function write_conformal(n::Int; mode::Symbol = :ordered, dir::AbstractString = ".")
    @assert n >= 3 "conformal polytope is defined for n >= 3"
    equal   = (mode == :equal)
    es      = edges(n)
    nH      = length(es)
    nVkept  = n * (n - 3)                               
    nvars   = nVkept + nH
    nparams = equal ? 1 : n
   
    P = Vector{Vector{Int}}()

    for i in 1:n
        vcoef = Dict{Int,Int}()
        for k in 1:(n - 3)                               
            vcoef[(i - 1) * (n - 3) + k] = -1
        end
        for (idx, (a, b)) in enumerate(es)               
            (a == i || b == i) && (vcoef[nVkept + idx] = -1)
        end
        pcol = equal ? 1 : i                             
        push!(P, polyrow(1, nvars, nparams; vcoef = vcoef, pcoef = Dict(pcol => 1)))
    end
    for idx in 1:nvars                                  
        push!(P, polyrow(1, nvars, nparams; vcoef = Dict(idx => 1)))
    end

    names = equal ? ["s"] : ["s$i" for i in 1:n]
    ctx   = equal ? equal_context() : ordered_context(nparams)
    write_barv(joinpath(dir, "conformal_$(mode)_n$(n).barv"), P, ctx, names)
end

# ---------------------------------------------------------------------------
# Transportation polytope T(r,c)                                 (Appendix A)
#
#  Variables : b_ij, 1<=i<=p, 1<=j<=q          (nvars = p*q)
#  Row sums  : sum_j b_ij = r_i     Column sums: sum_i b_ij = c_j
#  :ordered  -> params r_1..r_p, c_1..c_q with r and c each ordered and Σr = Σc
#  :equal    -> single param b, every margin = b (requires p == q)
# ---------------------------------------------------------------------------

function write_transportation(p::Int, q::Int = p;
                              mode::Symbol = :ordered, dir::AbstractString = ".")
    equal   = (mode == :equal)
    equal && @assert p == q "equal-margin transportation needs a square table (p == q)"
    nvars   = p * q
    bidx(i, j) = (i - 1) * q + j
    nparams = equal ? 1 : (p + q)
    P = Vector{Vector{Int}}()

    for i in 1:p                                        
        vcoef = Dict(bidx(i, j) => 1 for j in 1:q)
        push!(P, polyrow(0, nvars, nparams; vcoef = vcoef,
                         pcoef = Dict((equal ? 1 : i) => -1)))
    end
    for j in 1:q                                       
        vcoef = Dict(bidx(i, j) => 1 for i in 1:p)
        push!(P, polyrow(0, nvars, nparams; vcoef = vcoef,
                         pcoef = Dict((equal ? 1 : p + j) => -1)))
    end
    for idx in 1:nvars                                 
        push!(P, polyrow(1, nvars, nparams; vcoef = Dict(idx => 1)))
    end

    if equal
        names = ["b"]
        ctx   = equal_context()
    else
        names = vcat(["r$i" for i in 1:p], ["c$j" for j in 1:q])
        ctx   = Vector{Vector{Int}}()
        for k in 1:nparams                               
            push!(ctx, ctxrow(1, nparams; pcoef = Dict(k => 1)))
        end
        for i in 1:p-1                                  
            push!(ctx, ctxrow(1, nparams; pcoef = Dict(i => -1, i + 1 => 1)))
        end
        for j in 1:q-1                                  
            push!(ctx, ctxrow(1, nparams; pcoef = Dict(p + j => -1, p + j + 1 => 1)))
        end
        eqc = Dict{Int,Int}()                           
        for i in 1:p; eqc[i]     =  1; end
        for j in 1:q; eqc[p + j] = -1; end
        push!(ctx, ctxrow(0, nparams; pcoef = eqc))
    end

    tag = (p == q) ? "n$(p)" : "$(p)x$(q)"
    write_barv(joinpath(dir, "trans_$(mode)_$(tag).barv"), P, ctx, names)
end

# ---------------------------------------------------------------------------
#  barvinok runner 
# ---------------------------------------------------------------------------

"""Generate every .barv file for `n in ns`. Returns the list of paths written."""
function generate_all(; ns = 3:6, dir::AbstractString = "barv")
    mkpath(dir)
    files = String[]
    for n in ns, mode in (:ordered, :equal)
        push!(files, write_pmatching(n;   mode = mode, dir = dir))
        push!(files, write_fmatching(n;   mode = mode, dir = dir))
        push!(files, write_conformal(n;   mode = mode, dir = dir))
        push!(files, write_transportation(n; mode = mode, dir = dir))
    end
    return files
end

"""Run `barvinok_enumerate <flags> < infile > outfile`."""
function run_barvinok(infile::AbstractString, outfile::AbstractString;
                      exe = "barvinok_enumerate", flags = ["--to-isl"])
    open(outfile, "w") do out
        run(pipeline(`$exe $flags`, stdin = infile, stdout = out, stderr = out))
    end
    return outfile
end

"""
Run barvinok on every *.barv in `indir`, writing *.isl to `outdir`
"""
function run_all(indir::AbstractString = "barv", outdir::AbstractString = "isl";
                 flags = ["--to-isl"])
    mkpath(outdir)
    open(joinpath(outdir, "manifest.csv"), "w") do man
        println(man, "file,status,seconds")
        for f in sort(readdir(indir))
            endswith(f, ".barv") || continue
            inp = joinpath(indir, f)
            out = joinpath(outdir, replace(f, ".barv" => ".isl"))
            t0  = time()
            status = "ok"
            try
                run_barvinok(inp, out; flags = flags)
            catch err
                status = "error: $(err)"
            end
            dt = round(time() - t0; digits = 3)
            println(man, "$f,$status,$dt")
            @info "barvinok" file = f status = status seconds = dt
        end
    end
    return joinpath(outdir, "manifest.csv")
end


end # module
